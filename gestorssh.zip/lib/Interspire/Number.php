<?php

/**
* This class is a container for generic number methods.
*/
class Interspire_Number
{

}
