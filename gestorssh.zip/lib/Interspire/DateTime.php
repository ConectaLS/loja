<?php

/**
* This class is a container for generic date/time methods.
*/
class Interspire_DateTime
{
	const SECONDS_PER_DAY = 86400;
	const SECONDS_PER_HOUR = 3600;
	const SECONDS_PER_MINUTE = 60;
}
