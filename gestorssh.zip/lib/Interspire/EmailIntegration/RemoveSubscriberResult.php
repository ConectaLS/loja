<?php

/**
* This class defines a structure for the results of removing a subscriber from an email provider list.
*/
class Interspire_EmailIntegration_RemoveSubscriberResult extends Interspire_EmailIntegration_SubscriberActionResult
{

}
