<?php

class Interspire_EmailIntegration_EmailMarketer_Exception_InvalidResponse extends Interspire_EmailIntegration_EmailMarketer_Exception
{
	public $requestBody;
	public $responseBody;
}
