<?php

abstract class Interspire_EmailIntegration_MailChimp_Field extends Interspire_EmailIntegration_ProviderField
{

}
