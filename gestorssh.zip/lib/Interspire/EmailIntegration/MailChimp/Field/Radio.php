<?php

class Interspire_EmailIntegration_MailChimp_Field_Radio extends Interspire_EmailIntegration_MailChimp_Field_Text
{

}
