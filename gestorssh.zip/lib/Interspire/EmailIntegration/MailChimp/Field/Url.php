<?php

class Interspire_EmailIntegration_MailChimp_Field_Url extends Interspire_EmailIntegration_MailChimp_Field_Text
{

}
