<?php

class Interspire_EmailIntegration_MailChimp_Field_Imageurl extends Interspire_EmailIntegration_MailChimp_Field_Text
{

}
