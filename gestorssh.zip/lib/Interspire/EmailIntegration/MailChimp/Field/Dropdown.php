<?php

class Interspire_EmailIntegration_MailChimp_Field_Dropdown extends Interspire_EmailIntegration_MailChimp_Field_Text
{

}
