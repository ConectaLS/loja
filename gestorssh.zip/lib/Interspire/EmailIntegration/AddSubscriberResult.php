<?php

/**
* This class defines a structure for the results of adding a subscriber to an email provider list.
*/
class Interspire_EmailIntegration_AddSubscriberResult extends Interspire_EmailIntegration_SubscriberActionResult
{

}
