<?php

class Interspire_EmailIntegration_Subscription_Exception extends Interspire_EmailIntegration_Exception
{

}
