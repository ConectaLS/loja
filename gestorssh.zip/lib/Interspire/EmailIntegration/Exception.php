<?php

class Interspire_EmailIntegration_Exception extends Interspire_Exception
{

}
