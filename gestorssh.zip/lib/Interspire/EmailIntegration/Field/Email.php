<?php

class Interspire_EmailIntegration_Field_Email extends Interspire_EmailIntegration_Field_String
{

}
