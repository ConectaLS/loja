<?php

class Interspire_EmailIntegration_Field_Float extends Interspire_EmailIntegration_Field_Number
{

}
