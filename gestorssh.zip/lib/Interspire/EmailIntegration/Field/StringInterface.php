<?php

interface Interspire_EmailIntegration_Field_StringInterface
{
	public function valueToString($value);
}
