<?php

class Interspire_EmailIntegration_Field_Ip extends Interspire_EmailIntegration_Field_String
{

}
