<?php

class Interspire_EmailIntegration_Field_Int extends Interspire_EmailIntegration_Field_Number
{

}
