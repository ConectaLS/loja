<?php

class Interspire_EmailIntegration_Field_String extends Interspire_EmailIntegration_Field_Scalar
{

}
