<?php

interface Interspire_EmailIntegration_Field_NumberInterface
{
	public function valueToNumber($value);
}
