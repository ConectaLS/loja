<?php

class Interspire_TaskManager_TaskSaveException extends Interspire_TaskManager_Exception { }
