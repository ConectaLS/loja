<?php

class Interspire_TaskManager_InvalidCallbackException extends Interspire_TaskManager_Exception { }
