<?php

class Interspire_TaskManager_InvalidArgumentException extends Interspire_TaskManager_Exception { }
