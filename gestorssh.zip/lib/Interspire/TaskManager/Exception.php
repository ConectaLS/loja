<?php

class Interspire_TaskManager_Exception extends Exception { }
