<?php

/**
 * @author Interspire
 */

/**
 * A base exception class that all subpackage exception classes should extend.
 * 
 * @package Interspire
 * @subpackage Exception
 */
class Interspire_Exception extends Exception
{}