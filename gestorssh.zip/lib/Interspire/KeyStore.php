<?php

class Interspire_KeyStore extends Interspire_KeyStore_Base implements Interspire_KeyStore_Interface
{

}
