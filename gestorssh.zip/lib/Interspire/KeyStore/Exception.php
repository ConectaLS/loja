<?php

class Interspire_KeyStore_Exception extends Interspire_Exception
{

}
