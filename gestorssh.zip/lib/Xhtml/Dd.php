<?php

/**
* This class represents a DL element in XHTML
*/
class Xhtml_Dd extends Xhtml_TextElement
{
	protected $_tag = 'dd';
}
