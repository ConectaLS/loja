<?php

/**
* This class represents a DL element in XHTML
*/
class Xhtml_Dt extends Xhtml_TextElement
{
	protected $_tag = 'dt';
}
