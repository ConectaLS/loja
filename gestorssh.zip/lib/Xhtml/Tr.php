<?php

/**
* This class represents an TR element in XHTML
*/
class Xhtml_Tr extends Xhtml_Element
{
	protected $_tag = 'tr';
}
