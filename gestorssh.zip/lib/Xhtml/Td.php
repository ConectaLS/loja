<?php

/**
* This class represents an TR element in XHTML
*/
class Xhtml_Td extends Xhtml_TextElement
{
	protected $_tag = 'td';
}
