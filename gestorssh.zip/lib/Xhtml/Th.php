<?php

/**
* This class represents an TR element in XHTML
*/
class Xhtml_Th extends Xhtml_TextElement
{
	protected $_tag = 'th';
}
