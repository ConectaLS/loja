<?php

/**
* This class represents a DL element in XHTML
*/
class Xhtml_Dl extends Xhtml_Element
{
	protected $_tag = 'dl';
}
