<?php

/**
* This class represents an TABLE element in XHTML
*/
class Xhtml_Table extends Xhtml_Element
{
	protected $_tag = 'table';
}
