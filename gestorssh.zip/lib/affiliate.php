<?php
/**
 *
 * @ IonCube v8.3 Loader By DoraemonPT
 * @ PHP 5.3
 * @ Decoder version : 1.0.0.7
 * @ Author     : DoraemonPT
 * @ Release on : 09.05.2014
 * @ Website    : http://EasyToYou.eu
 *
 **/

function GiveAffiliateCredit($order) {
	if (!AFFILIATE_ENABLED) {
		return false;
	}

	$RATE = AFFILIATE_COMMISSION;
	$REASON = AFFILIATE_REASON;
	$AFFILIATE_CAN_BE_BUYER = AFFILIATE_SELF_AFFILIATE;	
	$oid = intval( $order['orderid'] );
	$amount = (AFFILIATE_INCLUDE_SHIPPING ? $order['total_inc_tax'] : $order['total_inc_tax'] - $order['shipping_cost_inc_tax']);
	$date = time();
	$aid = intval( $order['ordaffiliate'] );
	$cid = intval( $order['ordcustid'] );

	if (!$aid) {
		return false;
	}


	if (( $aid == $cid && !$AFFILIATE_CAN_BE_BUYER )) {
		return false;
	}


	if (0 < mysql_num_rows( mysql_query( '' . 'SELECT * FROM isc_customer_credits WHERE creditrefid=' . $oid ) )) {
		return false;
	}
	
	$amount = round( $amount * $RATE, 2 );;
	$amount += AFFILIATE_FIXED_AMOUNT;
	$query = '' . '
		INSERT INTO isc_customer_credits
			(customerid, creditamount, credittype, creditdate, creditrefid, credituserid, creditreason)
		VALUES (
			\'' . $cid . '\',
			\'' . $amount . '\',
			\'gift\',
			\'' . $date . '\',
			\'' . $oid . '\',
			\'' . $aid . '\',
			\'' . mysql_real_escape_string( $REASON ) . '\'
		)';
	mysql_query( $query );
	
	$error = mysql_error(  );;

	if ($error) {
		return false;
	}

	mysql_query( '' . 'UPDATE isc_customers SET custstorecredit=custstorecredit+' . $amount . ' WHERE customerid=' . $aid );
	return true;
}

function GetCommissionDetails() {
	$out = '';
	
	$afilporc = GetModuleVariable( 'addon_afiliados', 'porc' );;
	
	$curr = GetDefaultCurrency(  );;

	if (( AFFILIATE_COMMISSION && AFFILIATE_FIXED_AMOUNT )) {
		$out = '' . $afilporc . '% sobre o valor total do pedido ' . (AFFILIATE_INCLUDE_SHIPPING ? '' : '(exc.os custos de envio / manuseio)');
		$out .= ' e um fixo ' . FormatPriceInCurrency( AFFILIATE_FIXED_AMOUNT, $curr ) . ' bonus';
	}
	else {
		if (AFFILIATE_COMMISSION) {
			$out = '' . $afilporc . '% sobre o valor total do pedido ' . (AFFILIATE_INCLUDE_SHIPPING ? '' : '(exc. custos de transporte e manuseio)');
		}
		else {
			if (AFFILIATE_FIXED_AMOUNT) {
				$out = 'um fixo ' . FormatPriceInCurrency( AFFILIATE_FIXED_AMOUNT, $curr ) . ' bonus';
			}
			else {
				exit( 'O m�dulo de afiliados � mal configurado (0% commission, 0 bonus)' );
			}
		}
	}

	return $out;
}

function DisplayAffiliateAccountPage() {
	global $GLOBALS;
	
	$cid = $GLOBALS['ISC_CLASS_CUSTOMER']->GetCustomerId(  );;
	$customer = $GLOBALS['ISC_CLASS_CUSTOMER']->GetCustomerDataByToken(  );;
	$credit = CurrencyConvertFormatPrice( $customer['custstorecredit'] );;
	$credito = CurrencyConvertFormatPrice( $customer['custstorecredit'] );;
	$query = '' . '
		SELECT *
		FROM isc_customer_credits c
		WHERE credituserid=\'' . $cid . '\'
		AND creditreason=\'' . mysql_real_escape_string( AFFILIATE_REASON ) . '\'
		ORDER BY creditdate DESC
	';
	$result = $GLOBALS['ISC_CLASS_DB']->Query( $query );;
	$totalcredit = 5;
	$sales = '';
	

	if ($row = $GLOBALS['ISC_CLASS_DB']->Fetch( $result )) {
		$date = date( 'Y-m-d', $row['creditdate'] );;
		$credit = round( $row['creditamount'], 2 );;
		$fcredit = FormatPriceInCurrency( $credit, GetDefaultCurrency(  ) );;
		$oid = $row['creditrefid'];;
		$sales .= '' . '
			<li>[' . $row['custcreditid'] . '] Em ' . $date . ', voc� recebeu <b>' . $fcredit . '</b>. ID Pedido: ' . $oid . '.</li>
		';
		$totalcredit += $credit;;
	}
	
	$totalcredit = FormatPriceInCurrency( $totalcredit, GetDefaultCurrency(  ) );;
	$credit = FormatPriceInCurrency( $credit, GetDefaultCurrency(  ) );;
	$example = $GLOBALS['ShopPath'] . ( '' . '/?ref=' . $cid );
	$GLOBALS['AffiliateAccount'] = '
	<hr />
	<div style=\'text-align: justify;\'>
	<h2>Minha Conta de Afiliado</h2>

	Sabia que voc� pode ajudar ' . GetConfig( 'StoreName' ) . ' e fazer algum dinheiro s�rio ao mesmo tempo?
	Ao utilizar o nosso programa de afiliados voc� pode nos ajudar a obter novos clientes e ser recompensado por isso.<br><br>
	Para cada venda que voc� traz para ' . GetConfig( 'StoreName' ) . ' voc� vai ter ' . GetCommissionDetails(  ) . ( '' . '.
	<br /><br />

	<h3>Introdu��o</h3>
        Para come�ar a usar sua conta de Afiliado, simplesmente link nosso site colocando no final da url <u>?ref=' . $cid . '</u><br>
	Se um cliente clicar em link com sua ID de afilial e faz um pedido nos pr�ximos ' ) . AFFILIATE_COOKIE_DURATION . ( '' . ' dias,
	voc� receber� uma comiss�o correspondente h� cr�dito da loja.<br>
	Voc� pode ent�o usar o seu cr�dito na loja para fazer compras em nosso site, ou entrar em contato com o nosso suporte ao cliente para
	retirar o dinheiro em sua conta banc�ria.<br><br>Para criar links de afiliados, use qualquer liga��o ao nosso site, produtos ou categorias, e adicione o seguinte
	c�digo de afiliado no final do URL: <u>?ref=' . $cid . '</u>.&nbsp;&nbsp;exemplo: <u>' . $example . '</u>
	<br /><br />

	<h3>Minhas vendas de Afilial</h3>
	Seu saldo atual de cr�dito da loja: <b>' . $credito . '</b><br /><br>
	Lista de todas suas vendas realizadas atraves do link de afiliados!
	<ul>' . $sales . '</ul><br>
         <center>At� agora, voc� j� ganhou um total de<b>' . $totalcredit . '</b> na loja de cr�dito, gra�as �s suas vendas de afiliais*</center><br><br>
	* O valor � meramente informativo,n�o quer dizer que ainda tem esse cr�dito na loja,seu cr�dito dispon�vel para saque ou compras � de <b>' . $credito . '</b>.&nbsp;isso porque voc� j� deve ter feito pedidos na loja utilizando os cr�ditos
        ou at� mesmo em formas de saques em sua conta banc�ria.<br><br><hr>
	</div>
	' );
}


$afilativar = GetModuleVariable( 'addon_afiliados', 'ativar' );;
$afildias = GetModuleVariable( 'addon_afiliados', 'dias' );;
$afilporc = GetModuleVariable( 'addon_afiliados', 'porc' );;
$afilfixo = GetModuleVariable( 'addon_afiliados', 'fixo' );
$afilafiliado = GetModuleVariable( 'addon_afiliados', 'afiliado' );;
$afiltransporte = GetModuleVariable( 'addon_afiliados', 'transporte' );;

if ($afilativar == '1') {
	define( 'AFFILIATE_ENABLED', true );
}
else {
	define( 'AFFILIATE_ENABLED', false );
}

define( 'AFFILIATE_COOKIE_DURATION', $afildias );
define( 'AFFILIATE_COMMISSION', $afilporc / 100 );
define( 'AFFILIATE_FIXED_AMOUNT', $afilfixo );
define( 'AFFILIATE_REASON', 'AFFILIATE-CASHBACK' );

if ($afilafiliado == '1') {
	define( 'AFFILIATE_SELF_AFFILIATE', true );
}
else {
	define( 'AFFILIATE_SELF_AFFILIATE', false );
}


if ($afiltransporte == '1') {
	define( 'AFFILIATE_INCLUDE_SHIPPING', true );
}
else {
	define( 'AFFILIATE_INCLUDE_SHIPPING', false );
}


if (( isset( $_GET['ref'] ) && AFFILIATE_ENABLED )) {
	
	$ref = intval( $_GET['ref'] );;
	ISC_SetCookie( 'ref', $ref, time(  ) + 3600 * 24 * AFFILIATE_COOKIE_DURATION );
}

?>
