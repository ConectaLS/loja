<?php

class Resque_Exception extends Exception { }
