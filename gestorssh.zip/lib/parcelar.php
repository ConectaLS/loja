<?php
function ValorProduto($produto) {
		$query = "SELECT * FROM [|PREFIX|]products where productid=".$produto;
		$result = $GLOBALS['ISC_CLASS_DB']->Query($query);
		$a = $GLOBALS['ISC_CLASS_DB']->Fetch($result);
$GLOBALS['ISC_CLASS_CUSTOMER'] = GetClass('ISC_CUSTOMER');
$g = $GLOBALS['ISC_CLASS_CUSTOMER']->GetCustomerGroup();
$valor = $a['prodcalculatedprice']-(($a['prodcalculatedprice']/100)*$g['discount']);

return $valor;

}

function FreteTipo($produto) {
		$query = "SELECT * FROM [|PREFIX|]products where productid=".$produto;
		$result = $GLOBALS['ISC_CLASS_DB']->Query($query);
		$dados = $GLOBALS['ISC_CLASS_DB']->Fetch($result);
		if($dados['prodfreeshipping']==1){
		$d = '<img src="%%GLOBAL_ShopPath%%/modificacoes/frete_gratis.gif" border="0"><br>';
		return $d;
		}else{
		$s = '';
		return $s;
		}
}
		
function jurosSimples($valor, $taxa, $parcelas) {
$taxa = $taxa/100;
$m = $valor * (1 + $taxa * $parcelas);
$valParcela = $m/$parcelas;
return $valParcela;
}

function jurosComposto($valor, $taxa, $parcelas) {
$taxa = $taxa/100;
$valParcela = $valor * pow((1 + $taxa), $parcelas);
$valParcela = $valParcela/$parcelas;
return $valParcela;
}

function simulador_de_rodape($produto){



$ler = "select * from [|PREFIX|]module_vars where modulename = 'addon_parcelas' and variablename = 'rodape1' order by variablename asc";
$resultado = $GLOBALS['ISC_CLASS_DB']->Query($ler);
$parcelador = "<center>";
$s = $GLOBALS['ISC_CLASS_DB']->Fetch($resultado);
if(empty($s['variableval'])){
$s['variableval'] = 'pagseguro';
}
//inicio do switch
switch($s['variableval']) {


case 'pagseguro':
$ativo = GetModuleVariable('checkout_pagseguro','is_setup');
$juross = GetModuleVariable('checkout_pagseguro','acrecimo');
$nome = GetModuleVariable('checkout_pagseguro','displayname');
$pm = GetModuleVariable('checkout_pagseguro','minimo');
$div2 = GetModuleVariable('checkout_pagseguro','dividir');

if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}

$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div2){
$div = $splitss;
}else{
$div = GetModuleVariable('checkout_pagseguro','dividir');
}

//echo $div."<br>";
for($j=1; $j<=$div;$j++) {

$fator = array('0','0.51875','0.35007','0.26575','0.21518','0.18148','0.15743','0.13941','0.12540','0.11420','0.10505','0.09743');
$result_array = $fator[$j-1];
$parcelas = $valor*$result_array;

//echo $parcela."<br>";
$parcelas = number_format($parcelas, 2, '.', '');
//echo $parcela."<br>";
$valors = number_format($valor, 2, '.', '');
$op = GetModuleVariable('checkout_pagseguro','dividir');
if($div==$j){
if($j==1 OR $op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> sem juros no <b>Pagseguro</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> sem juros no <b>Pagseguro</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'<br>';
//fim do codigo de parcelamento
}
break;


case 'moip':
$ativo = GetModuleVariable('checkout_moip','is_setup');
$juross = GetModuleVariable('checkout_moip','acrecimo');
$nome = GetModuleVariable('checkout_moip','displayname');
$pm = GetModuleVariable('checkout_moip','minimo');
$div2 = GetModuleVariable('checkout_moip','dividir');

if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}

$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div2){
$div = $splitss;
}else{
$div = GetModuleVariable('checkout_moip','dividir');
}

//echo $div."<br>";
for($j=1; $j<=$div;$j++) {

$fator = array('0','0.51875','0.35007','0.26575','0.21518','0.18148','0.15743','0.13941','0.12540','0.11420','0.10505','0.09743');
$result_array = $fator[$j-1];
$parcelas = $valor*$result_array;

//echo $parcela."<br>";
$parcelas = number_format($parcelas, 2, '.', '');
//echo $parcela."<br>";
$valors = number_format($valor, 2, '.', '');
$op = GetModuleVariable('checkout_moip','dividir');
if($div==$j){
if($j==1 OR $op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> sem juros no <b>moip</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> sem juros no <b>moip</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'<br>';
//fim do codigo de parcelamento
}
break;

case 'mercadopago':
$ativo = GetModuleVariable('checkout_mercadopago','is_setup');
$juross = GetModuleVariable('checkout_mercadopago','acrecimo');
$nome = GetModuleVariable('checkout_mercadopago','displayname');
$pm = GetModuleVariable('checkout_mercadopago','minimo');
$div2 = GetModuleVariable('checkout_mercadopago','dividir');

if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}

$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div2){
$div = $splitss;
}else{
$div = GetModuleVariable('checkout_mercadopago','dividir');
}

//echo $div."<br>";
for($j=1; $j<=$div;$j++) {

$fator = array('0','0.51875','0.35007','0.26575','0.21518','0.18148','0.15743','0.13941','0.12540','0.11420','0.10505','0.09743');
$result_array = $fator[$j-1];
$parcelas = $valor*$result_array;

//echo $parcela."<br>";
$parcelas = number_format($parcelas, 2, '.', '');
//echo $parcela."<br>";
$valors = number_format($valor, 2, '.', '');
$op = GetModuleVariable('checkout_mercadopago','dividir');
if($div==$j){
if($j==1 OR $op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> sem juros no <b>mercadopago</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> sem juros no <b>mercadopago</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'<br>';
//fim do codigo de parcelamento
}
break;

case 'pagdigital':
$ativo = GetModuleVariable('checkout_pagamentodigital','is_setup');
$juross = GetModuleVariable('checkout_pagamentodigital','acrecimo');
$nome = GetModuleVariable('checkout_pagamentodigital','displayname');
$pm = GetModuleVariable('checkout_pagamentodigital','minimo');
$div2 = GetModuleVariable('checkout_pagamentodigital','dividir');

if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}

$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div2){
$div = $splitss;
}else{
$div = GetModuleVariable('checkout_pagamentodigital','dividir');
}

//echo $div."<br>";
for($j=1; $j<=$div;$j++) {

$fator = array('0','0.51875','0.35007','0.26575','0.21518','0.18148','0.15743','0.13941','0.12540','0.11420','0.10505','0.09743');
$result_array = $fator[$j-1];
$parcelas = $valor*$result_array;

//echo $parcela."<br>";
$parcelas = number_format($parcelas, 2, '.', '');
//echo $parcela."<br>";
$valors = number_format($valor, 2, '.', '');
$op = GetModuleVariable('checkout_pagamentodigital','dividir');
if($div==$j){
if($j==1 OR $op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> sem juros no <b>Bcash</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> sem juros no <b>Bcash</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'</br>';
//fim do codigo de parcelamento
}
break;

case 'cielo':
$ativo = GetModuleVariable('checkout_cielo','is_setup');
$nome = 'Cat&atilde;o de Credito';
$div = GetModuleVariable('checkout_cielo','div');
$juross = '0';
$taxa = 1.69;
$jt = 0;
$pm = GetModuleVariable('checkout_cielo','parcelamin');

if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}

$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div){
$div = $splitss;
}else{
$div = $div;
}
if($valor<=$pm){
$div = 1;
}

for($j=1; $j<=$div;$j++) {
if($div==$j){
if($jt==0)
$parcelas = jurosSimples($valor, $taxa, $j);
else
$parcelas = jurosComposto($valor, $taxa, $j);

$parcelas = number_format($parcelas, 2, '.', '');
$valors = number_format($valor, 2, '.', '');

$op = GetModuleVariable('checkout_cielo','jurosde');
if($op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> no <b>cart&atilde;o de credito</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> no <b>cart&atilde;o de credito</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'</br>';
//fim do codigo de parcelamento
}
break;

case 'cheque':
$ativo = GetModuleVariable('checkout_cheque','is_setup');
$juros = GetModuleVariable('checkout_cheque','juros');
$nome = GetModuleVariable('checkout_cheque','displayname');
$div = GetModuleVariable('checkout_cheque','dividir');
$jde = GetModuleVariable('checkout_cheque','jurosde');
$pmin = GetModuleVariable('checkout_cheque','parmin');
if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
if($juros<=0 OR empty($juros)){
$preco = CurrencyConvertFormatPrice($valordoproduto, 1, 0);
$msg = "<b>1x</b> de <b> ".$preco."</b> sem juros no <b>cheque</b>";
} else {
$msg = '';
$msg1 = '';
$splits = (int) ($valordoproduto/$pmin);
if($splits<=$div){
$div = $splits;
}else{
$div = $div;
}
for ($j=1;$j<=$div;$j++) {
if($div==$j){
if ($jde<=$j and $jde<='50') {
$valven = ($valordoproduto/100)*$juros;
$msg1 .= "<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice(($valordoproduto+$valven)/$j, 1, 0)."</b> com juros no <b>cheque</b>";
}else{
$msg .= "<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valordoproduto/$j, 1, 0)."</b>sem juros no <b>cheque</b>";
}
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'<br>';
//fim do codigo de parcelamento
}
break;

case 'paypal':
$ativo = GetModuleVariable('checkout_paypal','is_setup');
$juross = 0;
$nome = GetModuleVariable('checkout_paypal','displayname');
$pm = GetModuleVariable('checkout_paypal','minimo');
$div2 = GetModuleVariable('checkout_paypal','dividir');

if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}

$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div2){
$div = $splitss;
}else{
$div = GetModuleVariable('checkout_paypal','dividir');
}

//echo $div."<br>";
for($j=1; $j<=$div;$j++) {

$fator = array('0','0.51875','0.35007','0.26575','0.21518','0.18148','0.15743','0.13941','0.12540','0.11420','0.10505','0.09743');
$result_array = $fator[$j-1];
$parcelas = $valor*$result_array;

//echo $parcela."<br>";
$parcelas = number_format($parcelas, 2, '.', '');
//echo $parcela."<br>";
$valors = number_format($valor, 2, '.', '');
$op = GetModuleVariable('checkout_paypal','dividir');
if($div==$j){
if($j==1 OR $op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> sem juros no <b>Paypal</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> sem juros no <b>Paypal</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'</br>';
//fim do codigo de parcelamento
}
break;

case 'shopline':
$ativo = GetModuleVariable('checkout_itaushopline','is_setup');
$nome = GetModuleVariable('checkout_itaushopline','displayname');
$boleto = '';
$facil = '';
$finan = '';
$trans = '';
if(!empty($ativo)) {
//verifica o desconto
$valordoproduto = ValorProduto($produto);
$msg = "";
$preco = CurrencyConvertFormatPrice($valordoproduto, 1, 0);
$msg .= "<b>1x</b> de <b> ".$preco."</b> no <b>itau shopline</b>";
//inicio do codigo do parcelamento
$parcelador .= $msg.'</fbr>';
//fim do codigo de parcelamento
}
break;

case 'visacredito':
$ativo = GetModuleVariable('checkout_cartaodecreditomanual','is_setup');
$nome = "Cart�o de Cr�dito";
$div = GetModuleVariable('checkout_cartaodecreditomanual','dividir');
$juross = '0';
$taxa = GetModuleVariable('checkout_cartaodecreditomanual','juros');
$jt = GetModuleVariable('checkout_cartaodecreditomanual','tipojuros');
$pm = GetModuleVariable('checkout_cartaodecreditomanual','minimo');
if(!empty($ativo)) {
//verifica o juros
$valordoproduto = ValorProduto($produto);
$valor = $valordoproduto;
if($juross<=0 OR empty($juross)){
$valor = $valor;
} else {
$valor = (($valor/100)*$juross)+$valor;
}
$msg = '';
$msg1 = '';
$splitss = (int) ($valor/$pm);
if($splitss<=$div){
$div = $splitss;
}else{
$div = $div;
}
if($valor<=$pm){
$div = 1;
}
for($j=1; $j<=$div;$j++) {
if($div==$j){
if($jt==0)
$parcelas = jurosSimples($valor, $taxa, $j);
else
$parcelas = jurosComposto($valor, $taxa, $j);
$parcelas = number_format($parcelas, 2, '.', '');
$valors = number_format($valor, 2, '.', '');
$op = GetModuleVariable('checkout_cartaodecreditomanual','semjuros');
if($op>=$j) {
$msg .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($valors/$j, 1, 0)."</b> sem juros no <b>Cart�o de Cr�dito</b>";
}else{
$msg1 .="<b>".$j."x</b> de <b>".CurrencyConvertFormatPrice($parcelas, 1, 0)."</b> com juros no <b>Cart�o de Cr�dito</b>";
}
}
}
//inicio do codigo do parcelamento
$parcelador .= $msg.''.$msg1.'</br>';
//fim do codigo de parcelamento
}
break;

}

$ativodepotsito = GetModuleVariable('addon_parcelas','ativodesconto');
$porcedesconto = GetModuleVariable('addon_parcelas','descontohome');
if($ativodepotsito=='sim'){
if($porcedesconto>0){
$valordoproduto = ValorProduto($produto);
$valordoproduto = $valordoproduto-(($valordoproduto/100)*$porcedesconto);
$dep = '<b>'.CurrencyConvertFormatPrice($valordoproduto, 1, 0).'</b> � vista com desconto';
}else{
$valordoproduto = ValorProduto($produto);
$dep = '<b>'.CurrencyConvertFormatPrice($valordoproduto, 1, 0).'</b> no <b>deposito ou boleto</b>';
}

if($s['variableval']!=1){
$dep .= " ou "; 
}

}else{
$dep = '';
}

$frete = FreteTipo($produto);
$ss = $valordoproduto;
	if($ss=='0'){
	return '';
	}
$sl = GetModuleVariable('addon_somentelogado','lg');
	if(!CustomerIsSignedIn() && $sl=='sim'){
	return '';
	}

return '<center>'.$dep.''.$parcelador.''.$frete."<br></center></center>";


}
?>
