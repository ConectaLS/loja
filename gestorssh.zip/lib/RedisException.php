<?php

/**
 * Wraps native Redis errors in friendlier PHP exceptions
 */
class RedisException extends Exception { }
